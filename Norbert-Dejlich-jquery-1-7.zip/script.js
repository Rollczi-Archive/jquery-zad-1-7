$('#start').click(function() {
    $('p').addClass('start');
});

$('#stop').click(function() {
    $('p').removeClass('start');
});
